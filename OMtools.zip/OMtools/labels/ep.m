%ep.m: Eye Position axis labels
ylabel( 'Eye Position (�)' )