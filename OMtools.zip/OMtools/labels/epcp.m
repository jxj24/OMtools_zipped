%epcp.m: Eye Velocity Conjugacy Plot axis labels
ylabel( 'Left Eye Position (�)' )
xlabel( 'Right Eye Position (�)' )