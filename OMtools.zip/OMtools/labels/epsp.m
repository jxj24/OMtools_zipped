%epsp.m: Eye Position Scan Path axis labels
ylabel( 'Vertical Eye Position (�)' )
xlabel( 'Horizontal Eye Position (�)' )