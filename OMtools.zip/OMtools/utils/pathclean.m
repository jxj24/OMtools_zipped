function out=pathclean(in)

out=strrep(in,' ','\ ');